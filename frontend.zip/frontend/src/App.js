// frontend/src/App.js
import React from 'react';
import PaymentPage from './components/PaymentPage';

function App() {
  return <PaymentPage />;
}

export default App;